// mediapipe_hand_controller.js
import {
  HandLandmarker,
  PoseLandmarker,
  FilesetResolver
} from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs";


export class MediaPipeHandController {
    constructor(viewerInstance, videoElement) {
        this.viewer = viewerInstance;
        this.video = videoElement;
        this.handLandmarker = null;
        this.runningMode = "VIDEO";
        this.lastVideoTime = -1;
        this.webcamInitialized = false;
        this.resetTimer = null; // New: Timer for resetting hand
        this.resetDelay = 2000; // New: 2 seconds delay for reset
        this.isHandDetected = false; // New: Flag to track hand detection status

        this.initMediaPipe();
    }

    async initMediaPipe() {
        const vision = await FilesetResolver.forVisionTasks(
            "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm"
        );
        this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
            baseOptions: {
                modelAssetPath: '/mediapipe_models/hand_landmarker.task',  // Fully hardcoded path
                delegate: "GPU"
            },
            numHands: 1,
            runningMode: this.runningMode
        });
        console.log("MediaPipe HandLandmarker initialized.");
          

        // Initialize PoseLandmarker
        this.poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
            baseOptions: {
                modelAssetPath: '/mediapipe_models/pose_landmarker_heavy.task', // Using lite model for performance
                delegate: "GPU"
            },
            runningMode: this.runningMode
        });
        console.log("MediaPipe PoseLandmarker initialized.");
        this.setupWebcam();
    }

    setupWebcam() {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: true })
                .then((stream) => {
                    this.video.srcObject = stream;
                    this.video.addEventListener("canplay", () => {
                        this.video.play();
                        
                        this.overlayCanvas = document.getElementById("overlay");
                        this.overlayCanvas.width = this.video.videoWidth;
                        this.overlayCanvas.height = this.video.videoHeight;
                        this.overlayCtx = this.overlayCanvas.getContext("2d");

                        this.webcamInitialized = true;
                        console.log("Webcam stream started. Starting hand detection loop.");
                        this.detectHandsInRealTime();
                    }, { once: true });
                })
                .catch((error) => {
                    console.error("Error accessing webcam:", error);
                    this.viewer.updateStatus("Error accessing webcam: " + error.message, 'error');
                });
        } else {
            this.viewer.updateStatus("Webcam not supported by this browser.", 'error');
        }
    }

   async detectHandsInRealTime() {
    if (this.webcamInitialized && this.handLandmarker && this.poseLandmarker) {
        const startTimeMs = performance.now();

        if (this.video.currentTime !== this.lastVideoTime) {
            this.lastVideoTime = this.video.currentTime;

            try {
                const handResult = await this.handLandmarker.detectForVideo(this.video, startTimeMs);
                const poseResult = await this.poseLandmarker.detectForVideo(this.video, startTimeMs);

                const handLandmarks = handResult.landmarks?.[0] || [];
                const poseLandmarks = poseResult.landmarks?.[0] || [];

                if (handLandmarks.length > 0) {
                    this.isHandDetected = true;
                    clearTimeout(this.resetTimer);
                    this.mapPoseToRobot(poseLandmarks);
                    // this.mapHandToRobot(handLandmarks);
                }
               
                 else {
                    this.isHandDetected = false;
                    this.startResetTimer();
                }

                this.drawLandmarks(poseLandmarks, handLandmarks);

            } catch (error) {
                console.error("Detection error:", error);
                this.isHandDetected = false;
                this.startResetTimer();
                this.drawLandmarks([], []); // Clear overlay
            }
        }
    }

    requestAnimationFrame(this.detectHandsInRealTime.bind(this));
}


    // New: Start or restart the reset timer
    startResetTimer() {
        if (this.resetTimer) {
            clearTimeout(this.resetTimer);
        }
        this.resetTimer = setTimeout(() => {
            console.log("No hand detected for 2 seconds. Resetting robot to default pose and camera.");
            this.resetRobotPose(); // Call the new reset function
            // Optionally, also reset camera if desired
            if (this.viewer && this.viewer.resetCamera) {
                this.viewer.resetCamera();
            }
            this.viewer.updateStatus("Hand tracking idle. Robot and camera reset.", 'info');
        }, this.resetDelay);
    }

    // New: Function to reset all relevant joints to 0
    resetRobotPose() {
        if (this.viewer && this.viewer.joints) {
            for (const jointName in this.viewer.joints) {
                const joint = this.viewer.joints[jointName];
                // Only reset revolute/prismatic joints that are likely controlled by hand
                if (joint.type === 'revolute' || joint.type === 'continuous' || joint.type === 'prismatic') {
                     // Ensure the joint actually has a corresponding control or is part of your hand model
                     // You might want a more specific list of joints to reset if your robot has many
                    if (this.viewer.updateJoint) {
                        this.viewer.updateJoint(jointName, 0); // Reset to 0 position
                        // Also update the UI slider if it exists
                        if (this.viewer.jointControls && this.viewer.jointControls[jointName]) {
                            this.viewer.jointControls[jointName].value = 0;
                            const valueDisplay = this.viewer.jointControls[jointName].nextElementSibling;
                            if (valueDisplay) valueDisplay.textContent = '0.00';
                        }
                    }
                }
            }
        }
        // Also clear previousAngles for smoothing
        this.previousAngles = {};
    }

   drawLandmarks(poseLandmarks = [], handLandmarks = []) {
    if (!this.overlayCtx || !this.overlayCanvas) {
        if (this.debugMode) console.warn("Overlay canvas not initialized for drawing.");
        return;
    }

    this.overlayCtx.clearRect(0, 0, this.overlayCanvas.width, this.overlayCanvas.height);

    const scaleX = this.overlayCanvas.width;
    const scaleY = this.overlayCanvas.height;

    this.overlayCtx.save();
    this.overlayCtx.translate(this.overlayCanvas.width, 0);
    this.overlayCtx.scale(-1, 1);

    // --- 1. Draw Pose Landmarks ---
    if (poseLandmarks.length > 0) {
        const poseConnections = [
            [0, 1], [0, 4], [1, 2], [2, 3], [4, 5], [5, 6], [9, 10],
            [0, 7], [0, 8],
            [11, 12], [23, 24],
            [11, 23], [12, 24],
            [11, 13], [13, 15],
            [12, 14], [14, 16],
            [23, 25], [25, 27],
            [24, 26], [26, 28],
            [27, 29], [29, 31],
            [28, 30], [30, 32]
        ];

        this.overlayCtx.strokeStyle = '#33aaff';
        this.overlayCtx.lineWidth = 5;
        for (const [startIdx, endIdx] of poseConnections) {
            const start = poseLandmarks[startIdx];
            const end = poseLandmarks[endIdx];

            if (start && end &&
                (start.visibility === undefined || start.visibility > 0.5) &&
                (end.visibility === undefined || end.visibility > 0.5)) {
                this.overlayCtx.beginPath();
                this.overlayCtx.moveTo(start.x * scaleX, start.y * scaleY);
                this.overlayCtx.lineTo(end.x * scaleX, end.y * scaleY);
                this.overlayCtx.stroke();
            }
        }

        this.overlayCtx.fillStyle = '#FF4136';
        this.overlayCtx.strokeStyle = '#FFFFFF';
        this.overlayCtx.lineWidth = 2;
        for (let i = 0; i < poseLandmarks.length; i++) {
            const lm = poseLandmarks[i];
            if (lm && (lm.visibility === undefined || lm.visibility > 0.5)) {
                const x = lm.x * scaleX;
                const y = lm.y * scaleY;

                this.overlayCtx.beginPath();
                this.overlayCtx.arc(x, y, 7, 0, 2 * Math.PI);
                this.overlayCtx.fill();
                this.overlayCtx.stroke();
            }
        }
    }

    // --- 2. Draw Hand Landmarks ---
    if (handLandmarks.length > 0) {
        const handConnections = [
            [0, 1], [1, 2], [2, 3], [3, 4],
            [0, 5], [5, 6], [6, 7], [7, 8],
            [5, 9], [9, 10], [10, 11], [11, 12],
            [9, 13], [13, 14], [14, 15], [15, 16],
            [13, 17], [17, 18], [18, 19], [19, 20],
            [0, 17]
        ];

        this.overlayCtx.strokeStyle = '#00ff99';
        this.overlayCtx.lineWidth = 4;
        for (const [startIdx, endIdx] of handConnections) {
            const start = handLandmarks[startIdx];
            const end = handLandmarks[endIdx];

            if (start && end) {
                this.overlayCtx.beginPath();
                this.overlayCtx.moveTo(start.x * scaleX, start.y * scaleY);
                this.overlayCtx.lineTo(end.x * scaleX, end.y * scaleY);
                this.overlayCtx.stroke();
            }
        }

        // Finger Colors
        const fingerColors = ['#FF851B', '#2ECC40', '#FFDC00', '#7FDBFF', '#B10DC9'];
        const fingerIndices = [
            [1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12],
            [13, 14, 15, 16], [17, 18, 19, 20]
        ];

        for (let i = 0; i < fingerIndices.length; i++) {
            this.overlayCtx.fillStyle = fingerColors[i];
            for (const idx of fingerIndices[i]) {
                const lm = handLandmarks[idx];
                const x = lm.x * scaleX;
                const y = lm.y * scaleY;
                this.overlayCtx.beginPath();
                this.overlayCtx.arc(x, y, 6, 0, 2 * Math.PI);
                this.overlayCtx.fill();
                this.overlayCtx.stroke();
            }
        }

        // Draw palm base
        this.overlayCtx.fillStyle = '#F012BE';
        this.overlayCtx.beginPath();
        this.overlayCtx.arc(handLandmarks[0].x * scaleX, handLandmarks[0].y * scaleY, 8, 0, 2 * Math.PI);
        this.overlayCtx.fill();
        this.overlayCtx.stroke();
    }

    this.overlayCtx.restore();
}




   mapPoseToRobot(poseLandmarks) {
    if (!poseLandmarks[11] || !poseLandmarks[13]) return; // left_shoulder, left_elbow

    const shoulder = poseLandmarks[11];
    const elbow = poseLandmarks[13];

    const shoulderY = shoulder.y;
    const elbowY = elbow.y;

    // The more the elbow is below the shoulder, the higher the angle
    let verticalDelta = elbowY - shoulderY;

    // Map verticalDelta to joint range [-1.75, 1.75]
    // Typical verticalDelta range ~ [-0.1, 0.3] (you can tune this)
    let angle = (verticalDelta - 0.1) * 10; // Scale and center

    // Clamp to joint limits
    angle = Math.max(-1.75, Math.min(1.75, angle));

    // Optional: Smooth movement
    const smooth = (name, value, alpha = 0.4) => {
        if (!this.previousAngles) this.previousAngles = {};
        const prev = this.previousAngles[name] || 0;
        const smoothed = prev * (1 - alpha) + value * alpha;
        this.previousAngles[name] = smoothed;
        return smoothed;
    };

    if (this.viewer?.updateJoint) {
        this.viewer.updateJoint("shoulder_lift", smooth("shoulder_lift", angle));
    }

    if (this.viewer?.updateStatus) {
        this.viewer.updateStatus(`shoulder_lift angle: ${angle.toFixed(2)}`, "success");
    }

    
}

mapHandToRobot(handLandmarks) {
    const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

    if (!handLandmarks || handLandmarks.length < 21) return;

    // === Wrist Roll ===
    const wrist = handLandmarks[0];
    const indexBase = handLandmarks[5];
    const pinkyBase = handLandmarks[17];

    const v1 = new THREE.Vector3(indexBase.x - wrist.x, indexBase.y - wrist.y, indexBase.z - wrist.z);
    const v2 = new THREE.Vector3(pinkyBase.x - wrist.x, pinkyBase.y - wrist.y, pinkyBase.z - wrist.z);
    const normal = new THREE.Vector3().crossVectors(v1, v2).normalize();

    // Estimate roll as the X component of palm normal
    let rollAngle = Math.atan2(normal.x, normal.z); // or use quaternion for more accuracy

    // === Gripper Open/Close ===
    const thumbTip = handLandmarks[4];
    const indexTip = handLandmarks[8];

    const thumbVec = new THREE.Vector3(thumbTip.x, thumbTip.y, thumbTip.z);
    const indexVec = new THREE.Vector3(indexTip.x, indexTip.y, indexTip.z);
    const distance = thumbVec.distanceTo(indexVec);

    // Normalize distance to [0, 1] and invert for gripper close
    const gripperValue = clamp(1.0 - (distance * 6), 0, 1); // You may need to tune the multiplier

    // Smoothing (optional)
    const smooth = (name, value, alpha = 0.4) => {
        if (!this.previousAngles) this.previousAngles = {};
        const prev = this.previousAngles[name] || 0;
        const smoothed = prev * (1 - alpha) + value * alpha;
        this.previousAngles[name] = smoothed;
        return smoothed;
    };

    if (this.viewer?.updateJoint) {
        this.viewer.updateJoint("wrist_roll", smooth("wrist_roll", rollAngle));
        this.viewer.updateJoint("gripper", smooth("gripper", gripperValue));
    }
}


    
}